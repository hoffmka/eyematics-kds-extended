# Home - Eyematics Core Data Set v2025.0.0-alpha

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://eyematics.org/fhir/eyematics-kds/ImplementationGuide/eyematics-kerndatensatz | *Version*:2025.0.0-alpha |
| Draft as of 2025-10-17 | *Computable Name*:EyeMatics_KDS |

# EyeMatics-Kerndatensatz

Dies ist der Kerndatensatz des [EyeMatics-Projektes](https://www.eyematics.org/), welcher im Laufe der Zeit durch die Zuarbeit von ganz vielen tollen Menschen immer mehr erweitert und verbessert wird!

